<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <div class="jumbotron">
  <h1 class="display-4">WELCOME TO KENDARIKOTA.GO.ID</h1>
  <p class="lead">“Sesungguhnya Allah menyuruh kamu menyampaikan amanat kepada yang berhak menerimanya.” (An-Nisa`: 58)</p>
  <hr class="my-4">
  <p>“Tunaikanlah amanah pada orang yang memberikan amanah itu kepadamu, dan jangan kau khianati orang yang pernah mengkhianatimu.” (HR. Al-Imam Ahmad dan Ahlus Sunan)</p>
  <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
</div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->